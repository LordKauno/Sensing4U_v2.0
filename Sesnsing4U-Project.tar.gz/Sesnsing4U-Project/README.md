# Sesnsing4U
this application is to allow the user load data files, display and manage data, do search, update vales, sort all data inside of the program, update values and save the information. The main objective of this system is to help handling data from a lot of different sensors, reduce user errors and make easy the data processing.
